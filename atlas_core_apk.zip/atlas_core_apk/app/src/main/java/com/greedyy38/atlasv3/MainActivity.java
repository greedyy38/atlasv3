package com.greedyy38.atlasv3;
import android.app.*;import android.os.*;import android.webkit.*;import android.view.*;
public class MainActivity extends Activity{
  WebView w;
  @Override public void onCreate(Bundle b){super.onCreate(b);w=new WebView(this);setContentView(w);WebSettings s=w.getSettings();s.setJavaScriptEnabled(true);s.setAllowFileAccess(true);s.setAllowContentAccess(true);s.setDomStorageEnabled(true);w.setWebChromeClient(new WebChromeClient());w.setWebViewClient(new WebViewClient());w.loadUrl("file:///android_asset/index.html");}
  @Override public void onBackPressed(){if(w!=null&&w.canGoBack())w.goBack();else super.onBackPressed();}
}
